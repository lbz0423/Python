import matplotlib.pyplot as plt
from pylab import *

myfont = matplotlib.font_manager.FontProperties(fname="../../fontFormat/simsun.ttc", size=18)
mpl.rcParams['axes.unicode_minus'] = False


def draw_pic(data_1, data_2, data_3, data_4, save_file_name, num_diff):
    fig, ax = plt.subplots()
    index = np.arange(4)
    bar_width = 0.2
    plt.bar(index, data_1, bar_width, alpha=0.8, color='blue')
    plt.bar(index + bar_width, data_2, bar_width, alpha=0.8, color='red')
    plt.bar(index + bar_width + bar_width, data_3, bar_width, alpha=0.8, color='blue')
    plt.bar(index + 3 * bar_width, data_4, bar_width, alpha=0.8, color='red')
    plt.xlabel('数据集', fontproperties=myfont)
    if num_diff == "RMSE":
        plt.ylabel('RMSE值', fontproperties=myfont)
        plt.title('RMSE值数据集对比', fontproperties=myfont)
    elif num_diff == "MAE":
        plt.ylabel('MAE值', fontproperties=myfont)
        plt.title('MAE值数据集对比', fontproperties=myfont)
    elif num_diff == "MAPE":
        plt.ylabel('MAPE值', fontproperties=myfont)
        plt.title('MAPE值数据集对比', fontproperties=myfont)
    else:
        print("num_diff is error")
    plt.xticks(index + 1.5 * bar_width, ('日销量', '客运量', '出生率', '粮食占有量'), fontproperties=myfont)
    plt.yticks()
    plt.legend(['GRU模型', 'GRU-SES模型', ], prop=myfont, loc='upper right', bbox_to_anchor=(1,1.05))
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    plt.legend()
    fig = matplotlib.pyplot.gcf()
    fig.set_size_inches(14, 8)
    fig.savefig(save_file_name, dpi=350, bbox_inches='tight', transparent=True)


def bar_RMSE():
    ori_data_1 = (5191.38, 13001.73, 0.16, 93.77)
    ori_data_2 = (3758.18, 7229.22, 0.16, 64.40)
    ori_data_3 = (13003.84, 4575.13, 0.17, 112.57)
    ori_data_4 = (7726.95, 3685.18, 0.16, 70.10)
    data_1 = (ori_data_1[0], ori_data_1[1], ori_data_1[2] * 10000, ori_data_1[3] * 100)
    data_2 = (ori_data_2[0], ori_data_2[1], ori_data_2[2] * 10000, ori_data_2[3] * 100)
    data_3 = (ori_data_3[0], ori_data_3[1], ori_data_3[2] * 10000, ori_data_3[3] * 100)
    data_4 = (ori_data_4[0], ori_data_4[1], ori_data_4[2] * 10000, ori_data_4[3] * 100)
    save_file_name = "image/RMSE柱状图"
    draw_pic(data_1, data_2, data_3, data_4, save_file_name, "RMSE")


def bar_MAE():
    ori_data_1 = (3802.79, 10330.32, 0.13, 79.57)
    ori_data_2 = (2667.55, 5578.76, 0.12, 58)
    ori_data_3 = (9951.61, 3829.43, 0.14, 82.90)
    ori_data_4 = (6352.32, 2990.78, 0.11, 54.63)
    data_1 = (ori_data_1[0], ori_data_1[1], ori_data_1[2] * 10000, ori_data_1[3] * 100)
    data_2 = (ori_data_2[0], ori_data_2[1], ori_data_2[2] * 10000, ori_data_2[3] * 100)
    data_3 = (ori_data_3[0], ori_data_3[1], ori_data_3[2] * 10000, ori_data_3[3] * 100)
    data_4 = (ori_data_4[0], ori_data_4[1], ori_data_4[2] * 10000, ori_data_4[3] * 100)
    save_file_name = "image/MAE柱状图"
    draw_pic(data_1, data_2, data_3, data_4, save_file_name, "MAE")


def bar_MAPE():
    ori_data_1 = (323.96, 45.47, 1.04, 18.11)
    ori_data_2 = (237.73, 24.47, 0.98, 13.20)
    ori_data_3 = (618.08, 17.29, 1.11, 18.82)
    ori_data_4 = (417.08, 13.52, 0.94, 12.37)
    data_1 = (ori_data_1[0], ori_data_1[1] * 10, ori_data_1[2] * 100, ori_data_1[3] * 10)
    data_2 = (ori_data_2[0], ori_data_2[1] * 10, ori_data_2[2] * 100, ori_data_2[3] * 10)
    data_3 = (ori_data_3[0], ori_data_3[1] * 10, ori_data_3[2] * 100, ori_data_3[3] * 10)
    data_4 = (ori_data_4[0], ori_data_4[1] * 10, ori_data_4[2] * 100, ori_data_4[3] * 10)
    save_file_name = "image/MAPE柱状图"
    draw_pic(data_1, data_2, data_3, data_4, save_file_name, "MAPE")


bar_RMSE()
bar_MAE()
bar_MAPE()
