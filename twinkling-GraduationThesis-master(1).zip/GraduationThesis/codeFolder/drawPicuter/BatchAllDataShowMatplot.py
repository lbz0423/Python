import matplotlib.dates as mdates
import pandas as pd
from pylab import *

"""
导入中文显示，调整字体大小
示例图形可以参考 http://matplotlib.org/examples/api/date_demo.html
"""
myfont = matplotlib.font_manager.FontProperties(fname="../../fontFormat/simsun.ttc", size=18)
mpl.rcParams['axes.unicode_minus'] = False

"""
画图像，分别绘制四个数据集的波动图
"""
def draw_pic(data, new_date, save_file_name, data_set):
    fig, ax = plt.subplots()
    # 绘制线条颜色与宽度
    ax.plot(new_date, data, color='black', linewidth=2)
    fig.autofmt_xdate()
    plt.xlabel('日期', fontproperties=myfont)
    auto = mdates.AutoDateLocator()
    if data_set == "sale_model":
        # 对日期进行格式化
        dayFmt = mdates.DateFormatter('%Y-%m-%d')
        ax.xaxis.set_major_locator(auto)
        ax.xaxis.set_major_formatter(dayFmt)
        plt.ylabel('日销量(瓶)', fontproperties=myfont)
        plt.title("企业日销量数据集", fontproperties=myfont)
    elif data_set == "traffic_model":
        monthFmt = mdates.DateFormatter('%Y-%m')
        ax.xaxis.set_major_locator(auto)
        ax.xaxis.set_major_formatter(monthFmt)
        plt.ylabel('铁路客运量当期值(万人)', fontproperties=myfont)
        plt.title("铁路客运量当前期数据集", fontproperties=myfont)
    elif data_set == "birth_model":
        yearFmt = mdates.DateFormatter('%Y')
        ax.xaxis.set_major_locator(auto)
        ax.xaxis.set_major_formatter(yearFmt)
        plt.ylabel('人口出生率(‰)', fontproperties=myfont)
        plt.title("人口出生率数据集", fontproperties=myfont)
    elif data_set == "grain_model":
        yearFmt = mdates.DateFormatter('%Y')
        ax.xaxis.set_major_locator(auto)
        ax.xaxis.set_major_formatter(yearFmt)
        plt.ylabel('粮食人均占有量(公斤)', fontproperties=myfont)
        plt.title("粮食人均占有量数据集", fontproperties=myfont)
    else:
        print("data_set is error")
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    # 保存图像
    fig = matplotlib.pyplot.gcf()
    fig.set_size_inches(9, 5)
    fig.savefig(save_file_name, dpi=350, bbox_inches='tight', transparent=True)


def sale_data():
    # 文件位置thesisData
    file = '../../thesisData/日销量全部数据.csv'
    df = pd.read_csv(file)
    data = np.array(df['日销量'])
    date = np.array(df['日期'])
    new_date = []
    for i in range(len(date)):
        new_date_empty = datetime.datetime.strptime(date[i], '%Y/%m/%d')
        new_date.append(new_date_empty)
    save_file_name = "image/sale数据趋势图"
    draw_pic(data, new_date, save_file_name, "sale_model")


def traffic_data():
    file = '../../thesisData/铁路客运量全部数据.csv'
    df = pd.read_csv(file)
    data = np.array(df['铁路客运量当期值(万人)'])
    date = np.array(df['日期'])
    new_date = []
    for i in range(len(date)):
        new_date_empty = datetime.datetime.strptime(date[i], '%Y/%m')
        new_date.append(new_date_empty)
    save_file_name = "image/traffic数据趋势图"
    draw_pic(data, new_date, save_file_name, "traffic_model")


def birth_data():
    file = '../../thesisData/人口出生率全部数据.csv'
    df = pd.read_csv(file)
    data = np.array(df['人口出生率(‰)'])
    date = np.array(df['日期'])
    new_date = []
    for i in range(len(date)):
        new_date_empty = datetime.datetime.strptime(date[i], '%Y/')
        new_date.append(new_date_empty)
    save_file_name = "image/birth数据趋势图"
    draw_pic(data, new_date, save_file_name, "birth_model")


def grain_data():
    file = '../../thesisData/粮食占有量全部数据.csv'
    df = pd.read_csv(file)
    data = np.array(df['粮食人均占有量(公斤)'])
    date = np.array(df['日期'])
    new_date = []
    for i in range(len(date)):
        new_date_empty = datetime.datetime.strptime(date[i], '%Y/')
        new_date.append(new_date_empty)
    save_file_name = "image/grain数据趋势图"
    draw_pic(data, new_date, save_file_name, "grain_model")


sale_data()
traffic_data()
birth_data()
grain_data()
