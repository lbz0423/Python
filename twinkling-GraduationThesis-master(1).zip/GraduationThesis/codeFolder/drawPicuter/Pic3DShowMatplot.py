import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.gca(projection='3d')
x = [1, 2, 3, 4, 5, 6, 7]
y = [2, 3, 4, 5, 6, 7, 8]
ax.scatter(x, y, zs=0, zdir='y', color='black')
ax.legend()
ax.set_xlim(0, 9)
ax.set_ylim(0, 9)
ax.set_zlim(0, 9)
ax.set_xlabel('X')
ax.set_ylabel('Z')
ax.set_zlabel('Y')
ax.view_init(elev=20., azim=-35)
plt.show()
