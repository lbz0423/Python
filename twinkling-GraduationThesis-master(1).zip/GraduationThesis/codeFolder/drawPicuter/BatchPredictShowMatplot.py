import matplotlib.dates as mdates
import matplotlib.pyplot as plt
from pylab import *

myfont = matplotlib.font_manager.FontProperties(fname="../../fontFormat/simsun.ttc", size=18)
mpl.rcParams['axes.unicode_minus'] = False


# 日销量日期格式
def sale_date():
    date = ['2016/12/22', '2016/12/23', '2016/12/24', '2016/12/25', '2016/12/26', '2016/12/27', '2016/12/28',
            '2016/12/29', '2016/12/30', '2016/12/31']
    new_date = []
    for i in range(len(date)):
        new_date_empty = datetime.datetime.strptime(date[i], '%Y/%m/%d')
        new_date.append(new_date_empty)
    return new_date


# 客运量日期格式
def traffic_date():
    date = ['2016/8', '2016/9', '2016/10', '2016/11', '2016/12', '2017/1']
    new_date = []
    for i in range(len(date)):
        new_date_empty = datetime.datetime.strptime(date[i], '%Y/%m')
        new_date.append(new_date_empty)
    return new_date


# 出生率日期格式
def birth_date():
    date = ['2010', '2011', '2012', '2013', '2014', '2015']
    new_date = []
    for i in range(len(date)):
        new_date_empty = datetime.datetime.strptime(date[i], '%Y')
        new_date.append(new_date_empty)
    return new_date


# 粮食产量日期格式
def grain_date():
    date = ['2010', '2011', '2012', '2013', '2014', '2015']
    new_date = []
    for i in range(len(date)):
        new_date_empty = datetime.datetime.strptime(date[i], '%Y')
        new_date.append(new_date_empty)
    return new_date


# 画折线图
def drawPic(new_date, ori_data, gru_data, secgru_data, save_file_name, data_set):
    fig, ax = plt.subplots()
    ax.plot(new_date, ori_data, 'k', label='...', color='black', linewidth=2, marker="+")
    ax.plot(new_date, gru_data, 'k-.', label='...', color='blue', linewidth=2, marker="+")
    ax.plot(new_date, secgru_data, 'k:', label='...', color='red', linewidth=2, marker="+")

    if data_set == "sale_model":
        days = mdates.DayLocator()
        dayFmt = mdates.DateFormatter('%Y-%m-%d')
        ax.xaxis.set_major_locator(days)
        ax.xaxis.set_major_formatter(dayFmt)
        plt.ylabel('每日销售量(瓶)', fontproperties=myfont)
        plt.title('日销量数据集', fontproperties=myfont)
    elif data_set == "traffic_model":
        months = mdates.MonthLocator()
        monthFmt = mdates.DateFormatter('%Y-%m')
        ax.xaxis.set_major_locator(months)
        ax.xaxis.set_major_formatter(monthFmt)
        plt.ylabel('当期客运量(万人)', fontproperties=myfont)
        plt.title('客运量数据集', fontproperties=myfont)
    elif data_set == "birth_model":
        years = mdates.YearLocator()
        yearFmt = mdates.DateFormatter('%Y')
        ax.xaxis.set_major_locator(years)
        ax.xaxis.set_major_formatter(yearFmt)
        plt.ylabel('人口出生率(‰)', fontproperties=myfont)
        plt.title('出生率数据集', fontproperties=myfont)
    elif data_set == "grain_model":
        years = mdates.YearLocator()
        yearFmt = mdates.DateFormatter('%Y')
        ax.xaxis.set_major_locator(years)
        ax.xaxis.set_major_formatter(yearFmt)
        plt.ylabel('粮食人均占有量(公斤)', fontproperties=myfont)
        plt.title("人均粮食占有量数据集", fontproperties=myfont)
    else:
        print("data_set is error")

    fig.autofmt_xdate()
    plt.xlabel('日期', fontproperties=myfont)
    plt.legend(['真实值', 'GRU预测值', 'GRU-SES预测值'], prop=myfont)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    fig = matplotlib.pyplot.gcf()
    fig.set_size_inches(9, 5)
    fig.savefig(save_file_name, dpi=350, bbox_inches='tight', transparent=True)


# 日销量预测值折线图
def sale_model_1():
    new_date = sale_date()
    ori_data = [2580, 677, 4059, 1131, 3199, 1452, 3765, 1745, 1142, 1746]
    gru_data = [975.46, 12958.56, 3004.83, 0, 9230.48, 9050.21, 2021.69, 3214.65, 4509.98, 0]
    secgru_data = [3125.03, 9111.72, 4130.0, 2096.44, 7233.11, 7138.11, 3618.99, 4210.62, 4853.42, 1129.99]
    save_file_name = "image/sale_model_1折线图"
    drawPic(new_date, ori_data, gru_data, secgru_data, save_file_name, "sale_model")


def sale_model_2():
    new_date = sale_date()
    ori_data = [2580, 677, 4059, 1131, 3199, 1452, 3765, 1745, 1142, 1746]
    gru_data = [938.83, 9364.61, 11751.98, 21122.08, 10771.73, 8837.27, 22156.25, 28249.16, 2121.04, 2416.85]
    secgru_data = [3106.71, 7314.74, 8503.57, 13183.76, 8003.73, 7031.64, 13686.27, 16727.87, 3658.95, 3802.0]
    save_file_name = "image/sale_model_2折线图"
    drawPic(new_date, ori_data, gru_data, secgru_data, save_file_name, "sale_model")


# 客运量预测值折线图
def traffic_model_1():
    new_date = traffic_date()
    ori_data = [28007, 23918, 25001, 20409, 20768, 24756]
    gru_data = [26848.49, 13248.6, 10570.11, 17301.31, 45715.75, 17088.3]
    secgru_data = [25694.89, 19016.9, 17799.61, 21287.16, 35616.34, 21424.57]
    save_file_name = "image/traffic_model_1折线图"
    drawPic(new_date, ori_data, gru_data, secgru_data, save_file_name, "traffic_model")


def traffic_model_2():
    new_date = traffic_date()
    ori_data = [28007, 23918, 25001, 20409, 20768, 24756]
    gru_data = [26765.58, 24975.4, 21401.48, 26724.74, 28616.1, 21841.62]
    secgru_data = [25653.44, 24880.23, 23215.29, 25998.88, 27066.51, 23801.23]
    save_file_name = "image/traffic_model_2折线图"
    drawPic(new_date, ori_data, gru_data, secgru_data, save_file_name, "traffic_model")


# 出生率预测值折线图
def birth_model_1():
    new_date = birth_date()
    ori_data = [11.9, 11.93, 12.1, 12.08, 12.37, 12.07]
    gru_data = [12.08, 12.06, 12.05, 12.04, 12.04, 12.04]
    secgru_data = [12.12, 12.11, 12.1, 12.09, 12.08, 12.08]
    save_file_name = "image/birth_model_1折线图"
    drawPic(new_date, ori_data, gru_data, secgru_data, save_file_name, "birth_model")


def birth_model_2():
    new_date = birth_date()
    ori_data = [11.9, 11.93, 12.1, 12.08, 12.37, 12.07]
    gru_data = [12.06, 12.03, 12.03, 12.02, 12.01, 12.01]
    secgru_data = [12.11, 12.09, 12.09, 12.08, 12.07, 12.07]
    save_file_name = "image/birth_model_2折线图"
    drawPic(new_date, ori_data, gru_data, secgru_data, save_file_name, "birth_model")


# 粮食产量预测值折线图
def grain_model_1():
    new_date = grain_date()
    ori_data = [408.66, 425.15, 436.5, 443.46, 444.95, 453.2]
    gru_data = [398.71, 353.15, 339.06, 276.63, 351.61, 415.35]
    secgru_data = [395.48, 374.02, 368.31, 338.42, 377.25, 410.44]
    save_file_name = "image/grain_model_1折线图"
    drawPic(new_date, ori_data, gru_data, secgru_data, save_file_name, "grain_model")


def grain_model_2():
    new_date = grain_date()
    ori_data = [408.66, 425.15, 436.5, 443.46, 444.95, 453.2]
    gru_data = [398.70, 480.20, 359.27, 336.90, 209.55, 439.98]
    secgru_data = [395.47, 437.55, 378.41, 368.56, 306.21, 422.76]
    save_file_name = "image/grain_model_2折线图"
    drawPic(new_date, ori_data, gru_data, secgru_data, save_file_name, "grain_model")


sale_model_1()
sale_model_2()
traffic_model_1()
traffic_model_2()
birth_model_1()
birth_model_2()
grain_model_1()
grain_model_2()
