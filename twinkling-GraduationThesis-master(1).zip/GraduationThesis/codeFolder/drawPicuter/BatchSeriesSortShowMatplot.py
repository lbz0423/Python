from pylab import *
import random

myfont = matplotlib.font_manager.FontProperties(fname="../../fontFormat/simsun.ttc", size=18)
mpl.rcParams['axes.unicode_minus'] = False


def draw_pic(data, save_file_name, sort):
    fig, ax = plt.subplots()
    ax.plot(data, color='black', linewidth=2)
    if sort == "steady":
        plt.title("平稳型时间序列", fontproperties=myfont)
    elif sort == "astatic":
        plt.title("无定向型时间序列", fontproperties=myfont)
    elif sort == "trend":
        plt.title("趋势型时间序列", fontproperties=myfont)
    elif sort == "event":
        plt.title("介入事件型时间序列", fontproperties=myfont)
    else:
        print("sort is error")
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_xticks([])
    ax.set_yticks([])
    plt.legend()
    fig = matplotlib.pyplot.gcf()
    fig.set_size_inches(6, 4)
    fig.savefig(save_file_name, dpi=350, bbox_inches='tight', transparent=True)


def sort_steady():
    data = []
    for i in range(120):
        empty = random.randint(20, 30)
        data.append(empty)
    save_file_name = "image/平稳型时间序列"
    sort = "steady"
    draw_pic(data, save_file_name, sort)


def sort_astatic():
    data = []
    for i in range(40):
        empty = random.randint(20, 30)
        data.append(empty)
    for i in range(20):
        empty = random.randint(25, 35)
        data.append(empty)
    for i in range(20):
        empty = random.randint(15, 25)
        data.append(empty)
    for i in range(40):
        empty = random.randint(15, 25)
        data.append(empty)
    save_file_name = "image/无定向型时间序列"
    sort = "astatic"
    draw_pic(data, save_file_name, sort)


def sort_trend():
    data = []
    for i in range(10):
        empty = random.randint(20, 25)
        data.append(empty)
    for i in range(10):
        empty = random.randint(22, 27)
        data.append(empty)
    for i in range(10):
        empty = random.randint(24, 29)
        data.append(empty)
    for i in range(10):
        empty = random.randint(26, 31)
        data.append(empty)
    for i in range(10):
        empty = random.randint(28, 33)
        data.append(empty)
    for i in range(10):
        empty = random.randint(30, 35)
        data.append(empty)
    for i in range(10):
        empty = random.randint(32, 37)
        data.append(empty)
    for i in range(10):
        empty = random.randint(34, 39)
        data.append(empty)
    for i in range(10):
        empty = random.randint(36, 41)
        data.append(empty)
    for i in range(10):
        empty = random.randint(38, 43)
        data.append(empty)
    for i in range(10):
        empty = random.randint(40, 45)
        data.append(empty)
    for i in range(10):
        empty = random.randint(42, 47)
        data.append(empty)
    save_file_name = "image/趋势型时间序列"
    sort = "trend"
    draw_pic(data, save_file_name, sort)


def sort_event():
    data = []
    for i in range(50):
        empty = random.randint(20, 30)
        data.append(empty)
    for i in range(20):
        empty = random.randint(40, 50)
        data.append(empty)
    for i in range(50):
        empty = random.randint(20, 30)
        data.append(empty)
    save_file_name = "image/介入事件型时间序列"
    sort = "event"
    draw_pic(data, save_file_name, sort)


sort_steady()
sort_astatic()
sort_trend()
sort_event()
