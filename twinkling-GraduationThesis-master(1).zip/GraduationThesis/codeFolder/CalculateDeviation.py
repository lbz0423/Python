import numpy as np

"""
计算误差值
"""
ori_data = [28007, 23918, 25001, 20409, 20768, 24756]
gru_data = [26848.49, 13248.6, 10570.11, 17301.31, 45715.75, 17088.3]
secgru_data = [25694.89, 19016.9, 17799.61, 21287.16, 35616.34, 21424.57]


def calculate_RMSE(ori_data, gru_data, secgru_data):
    print('RMSE---------')
    b = 0
    for i in range(0, len(ori_data)):
        a = np.square(gru_data[i] - ori_data[i])
        b = b + a
    c = np.sqrt(b / (len(ori_data)))
    print(c)

    f = 0
    for j in range(0, len(ori_data)):
        e = np.square(secgru_data[j] - ori_data[j])
        f = f + e
    g = np.sqrt(f / (len(ori_data)))
    print(g)
    print('RMSE END---------')


def calculate_MAE(ori_data, gru_data, secgru_data):
    print('MAE---------')
    b = 0
    for i in range(0, len(ori_data)):
        a = abs(gru_data[i] - ori_data[i])
        b = b + a
    c = b / (len(ori_data))
    print(c)

    f = 0
    for j in range(0, len(ori_data)):
        e = abs(secgru_data[j] - ori_data[j])
        f = f + e
    g = f / (len(ori_data))
    print(g)
    print('MAE END---------')


def calculate_MAPE(ori_data, gru_data, secgru_data):
    print('MAPE---------')
    b = 0
    for i in range(0, len(ori_data)):
        a = abs((gru_data[i] - ori_data[i]) / ori_data[i])
        b = b + a
    c = (b * 100) / (len(ori_data))
    print(c)

    f = 0
    for j in range(0, len(ori_data)):
        e = abs((secgru_data[j] - ori_data[j]) / ori_data[j])
        f = f + e
    g = (f * 100) / (len(ori_data))
    print(g)
    print('MAPE END---------')


calculate_RMSE(ori_data, gru_data, secgru_data)
calculate_MAE(ori_data, gru_data, secgru_data)
calculate_MAPE(ori_data, gru_data, secgru_data)
