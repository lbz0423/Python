import numpy as np
import pandas as pd

# 销量数据
file = '/home/data/paperData/日销量测试数据.csv'
df = pd.read_csv(file)
data = np.array(df['日销量'])

# 客运量数据
file = '/home/data/paperData/铁路客运量测试数据.csv'
df = pd.read_csv(file)
data = np.array(df['客运量'])

mean_data = np.mean(data)
std_data = np.std(data)
normalized_data = (data - mean_data) / std_data

normalized_data_reverse = normalized_data[::-1]
normalized_data_reverse = normalized_data_reverse[0:30]
normalized_data_reverse = normalized_data_reverse[::-1]


def prediction():
    predict_day = 7
    # 二阶平滑
    St_1 = []
    St_2 = []
    St_1.append(normalized_data_reverse[0])
    St_2.append(normalized_data_reverse[0])
    a = 0.2
    for m in range(1, len(normalized_data_reverse)):
        St_1_empty = np.add(np.multiply(a, normalized_data_reverse[m]), np.multiply((1 - a), St_1[m - 1]))
        St_1.append(St_1_empty)
    for n in range(1, len(normalized_data_reverse)):
        St_2_empty = np.add(np.multiply(a, St_1[n]), np.multiply((1 - a), St_2[n - 1]))
        St_2.append(St_2_empty)
    an = 2 * St_1[-1] - St_2[-1]
    bn = np.true_divide(np.multiply(a, np.subtract(St_1[-1], St_2[-1])), (1 - a))
    print(St_1)
    print(St_2)
    predict_second = []
    for l in range(1, predict_day + 1):
        predict_empty = an + bn * l
        predict_second.append(predict_empty)
    print(predict_second)

    predict_restored = np.add(np.multiply(std_data, predict_second), mean_data)
    print(predict_restored)


prediction()
