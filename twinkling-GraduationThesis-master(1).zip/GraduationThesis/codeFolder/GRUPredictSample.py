import numpy as np
import pandas as pd
import tensorflow as tf

# 客运量数据
file = '../thesisData/铁路客运量测试数据.csv'
df = pd.read_csv(file)
data = np.array(df['客运量'])

mean_data = np.mean(data)
std_data = np.std(data)
normalized_data = (data - mean_data) / std_data

seq_size = 3
train_x = []
train_y = []
for i in range(len(normalized_data) - seq_size):
    train_x.append(np.expand_dims(normalized_data[i: i + seq_size], axis=1).tolist())
    train_y.append(normalized_data[i + 1: i + seq_size + 1].tolist())

X = tf.placeholder(tf.float32, [None, seq_size, 1])
Y = tf.placeholder(tf.float32, [None, seq_size])

predict_day = 6  # 预测天数
hidden_layer_size = 8
Weights = tf.Variable(tf.random_normal([hidden_layer_size, 1]), name='Weights')
biases = tf.Variable(tf.random_normal([1]), name='biases')
cell = tf.contrib.rnn.GRUCell(hidden_layer_size)
outputs, states = tf.nn.dynamic_rnn(cell, X, dtype=tf.float32)
W_repeated = tf.tile(tf.expand_dims(Weights, 0), [tf.shape(X)[0], 1, 1])
out = tf.squeeze(tf.matmul(outputs, W_repeated) + biases)
saver = tf.train.Saver(tf.global_variables())
with tf.Session() as sess:
    # 训练出的模型
    load_path = 'trainModel/05311919model.ckpt'
    saver.restore(sess, load_path)
    prev_seq = train_x[-1]
    predict_rnn = []
    for i in range(predict_day):
        next_seq = sess.run(out, feed_dict={X: [prev_seq]})
        predict_rnn.append(next_seq[-1])
        prev_seq = np.vstack((prev_seq[1:], next_seq[-1]))
print(predict_rnn)
predict_restored = np.add(np.multiply(std_data, predict_rnn), mean_data)
print(predict_restored)
a = []
for q in range(len(predict_restored)):
    a.append(float('%.2f' % (predict_restored[q])))
print(a)
