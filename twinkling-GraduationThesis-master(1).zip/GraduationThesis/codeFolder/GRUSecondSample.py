import numpy as np
import pandas as pd
import tensorflow as tf

# 客运量数据
file = '../thesisData/铁路客运量测试数据.csv'
df = pd.read_csv(file)
data = np.array(df['客运量'])

mean_data = np.mean(data)
std_data = np.std(data)
normalized_data = (data - mean_data) / std_data

normalized_data_reverse = normalized_data[::-1]
normalized_data_reverse = normalized_data_reverse[0:10]
normalized_data_reverse = normalized_data_reverse[::-1]

seq_size = 3
train_x = []
train_y = []
for i in range(len(normalized_data) - seq_size):
    train_x.append(np.expand_dims(normalized_data[i: i + seq_size], axis=1).tolist())
    train_y.append(normalized_data[i + 1: i + seq_size + 1].tolist())

X = tf.placeholder(tf.float32, [None, seq_size, 1])
Y = tf.placeholder(tf.float32, [None, seq_size])

predict_day = 6  # 预测天数
hidden_layer_size = 8
Weights = tf.Variable(tf.random_normal([hidden_layer_size, 1]), name='Weights')
biases = tf.Variable(tf.random_normal([1]), name='biases')
cell = tf.contrib.rnn.GRUCell(hidden_layer_size)
outputs, states = tf.nn.dynamic_rnn(cell, X, dtype=tf.float32)
W_repeated = tf.tile(tf.expand_dims(Weights, 0), [tf.shape(X)[0], 1, 1])
out = tf.squeeze(tf.matmul(outputs, W_repeated) + biases)
saver = tf.train.Saver(tf.global_variables())
with tf.Session() as sess:
    # 训练出的模型
    load_path = 'trainModel/05311919model.ckpt'
    saver.restore(sess, load_path)
    prev_seq = train_x[-1]
    predict_rnn = []
    for i in range(predict_day):
        next_seq = sess.run(out, feed_dict={X: [prev_seq]})
        predict_rnn.append(next_seq[-1])
        prev_seq = np.vstack((prev_seq[1:], next_seq[-1]))
print(predict_rnn)

St_1 = []
St_2 = []
St_1.append(normalized_data_reverse[0])
St_2.append(normalized_data_reverse[0])
a = 0.3
for m in range(1, len(normalized_data_reverse)):
    St_1_empty = np.add(np.multiply(a, normalized_data_reverse[m]), np.multiply((1 - a), St_1[m - 1]))
    St_1.append(St_1_empty)
for n in range(1, len(normalized_data_reverse)):
    St_2_empty = np.add(np.multiply(a, St_1[n]), np.multiply((1 - a), St_2[n - 1]))
    St_2.append(St_2_empty)
an = 2 * St_1[-1] - St_2[-1]
bn = np.true_divide(np.multiply(a, np.subtract(St_1[-1], St_2[-1])), (1 - a))
predict_second = []
for l in range(1, predict_day + 1):
    predict_empty = an + bn * l
    predict_second.append(predict_empty)
print(predict_second)

predict_final = []
for p in range(len(predict_rnn)):
    predict_final_empty = np.divide(np.add(predict_rnn[p], predict_second[p]), 2)
    predict_final.append(predict_final_empty)

predict_restored = np.add(np.multiply(std_data, predict_final), mean_data)
print(predict_restored)
a = []
for q in range(0, len(predict_restored)):
    a.append(float('%.2f' % (predict_restored[q])))
print(a)
