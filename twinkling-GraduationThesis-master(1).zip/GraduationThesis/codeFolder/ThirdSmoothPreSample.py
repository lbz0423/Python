import numpy as np
import pandas as pd

file = '/home/data/paperData/日销量测试数据.csv'
df = pd.read_csv(file)
data = np.array(df['日销量'])

mean_data = np.mean(data)
std_data = np.std(data)
normalized_data = (data - mean_data) / std_data

normalized_data_reverse = normalized_data[::-1]
normalized_data_reverse = normalized_data_reverse[0:20]
normalized_data_reverse = normalized_data_reverse[::-1]


def prediction():
    predict_day = 7
    # 二阶平滑
    St_1 = []
    St_2 = []
    St_3 = []
    St_1.append(normalized_data_reverse[0])
    St_2.append(normalized_data_reverse[0])
    St_3.append(normalized_data_reverse[0])
    a = 0.2
    for m in range(1, len(normalized_data_reverse)):
        St_1_empty = np.add(np.multiply(a, normalized_data_reverse[m]), np.multiply((1 - a), St_1[m - 1]))
        St_1.append(St_1_empty)
    for n in range(1, len(normalized_data_reverse)):
        St_2_empty = np.add(np.multiply(a, St_1[n]), np.multiply((1 - a), St_2[n - 1]))
        St_2.append(St_2_empty)
    for l in range(1, len(normalized_data_reverse)):
        St_3_empty = np.add(np.multiply(a, St_2[l]), np.multiply((1 - a), St_3[l - 1]))
        St_3.append(St_3_empty)

    at = 3 * St_1[-1] - 3 * St_2[-1] + St_3[-1]
    bt = (a * ((6 - 5 * a) * St_1[-1] - 2 * (5 - 4 * a) * St_2[-1] + (4 - 3 * a) * St_3[-1])) / (2 * (1 - a) * (1 - a))
    ct = ((a * a) * (St_1[-1] - 2 * St_2[-1] + St_3[-1])) / (2 * (1 - a) * (1 - a))

    predict_third = []
    for k in range(1, predict_day + 1):
        predict_empty = at + bt * k + ct * k * k
        predict_third.append(predict_empty)
    print(predict_third)

    predict_restored = np.add(np.multiply(std_data, predict_third), mean_data)
    print(predict_restored)


prediction()
