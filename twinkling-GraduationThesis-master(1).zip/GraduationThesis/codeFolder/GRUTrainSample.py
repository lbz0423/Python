from time import strftime

import numpy as np
import pandas as pd
import tensorflow as tf

# 客运量数据
file = '../thesisData/铁路客运量测试数据.csv'
df = pd.read_csv(file)
data = np.array(df['客运量'])

mean_data = np.mean(data)
std_data = np.std(data)
normalized_data = (data - mean_data) / std_data

seq_size = 3
train_x = []
train_y = []
for i in range(len(normalized_data) - seq_size):
    train_x.append(np.expand_dims(normalized_data[i: i + seq_size], axis=1).tolist())
    train_y.append(normalized_data[i + 1: i + seq_size + 1].tolist())

X = tf.placeholder(tf.float32, [None, seq_size, 1])
Y = tf.placeholder(tf.float32, [None, seq_size])

hidden_layer_size = 8
Weights = tf.Variable(tf.random_normal([hidden_layer_size, 1]), name='Weights')
biases = tf.Variable(tf.random_normal([1]), name='biases')
cell = tf.contrib.rnn.GRUCell(hidden_layer_size)
outputs, states = tf.nn.dynamic_rnn(cell, X, dtype=tf.float32)
W_repeated = tf.tile(tf.expand_dims(Weights, 0), [tf.shape(X)[0], 1, 1])
out = tf.squeeze(tf.matmul(outputs, W_repeated) + biases)
loss = tf.reduce_mean(tf.square(out - Y))
train_op = tf.train.AdamOptimizer(learning_rate=0.003).minimize(loss)
saver = tf.train.Saver(tf.global_variables())
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    for step in range(1001):
        _, loss_ = sess.run([train_op, loss], feed_dict={X: train_x, Y: train_y})
        if step % 1000 == 0:
            print(step, loss_)

    save_path = 'trainModel/' + strftime("%m%d%H%M") + 'model.ckpt'
    print("保存模型: ", saver.save(sess, save_path))
