from pylab import *

myfont = matplotlib.font_manager.FontProperties(fname="E:\\fonts\msyhbd.ttf")
mpl.rcParams['axes.unicode_minus'] = False

number = [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]
# 日销量预测值

# model_1
# data = [7.22871, 0.562585, 0.514986, 0.456482, 0.421824, 0.402355, 0.384583, 0.349648, 0.330798, 0.321975, 0.309632]
# model_2
data = [2.72894, 0.51762, 0.447001, 0.417196, 0.356624, 0.346069, 0.337471, 0.332146, 0.32889, 0.325853, 0.323924]

# 客运量预测值
# model_1
# data = [2.42395, 0.16457, 0.160613, 0.147079, 0.131923, 0.116209, 0.106926, 0.101968, 0.0969781, 0.0929537, 0.091014]
# model_2
# data = [1.18172, 0.161322, 0.143592, 0.120337, 0.104545, 0.0938115, 0.0904815, 0.0888418, 0.0875447, 0.0864287, 0.0856688]

# 出生率预测值
# model_1
# data = [1.01634, 0.0196369, 0.0163004, 0.0154602, 0.0150509, 0.0143412, 0.0128344, 0.0110996, 0.0106657, 0.0102661, 0.0100583]
# model_2
# data = [3.48759, 0.0211927, 0.0174672, 0.0162907, 0.0156852, 0.0152222, 0.0144851, 0.012681, 0.0122736, 0.0120155, 0.0117409]

# 粮食预测值
# model_1
# data = [1.86257, 0.335308, 0.165918, 0.132558, 0.127702, 0.124428, 0.123784, 0.123518, 0.123244, 0.122923, 0.12239]
# model_2
# data = [2.51032, 0.327179, 0.174195, 0.133719, 0.130584, 0.128395, 0.127067, 0.126075, 0.125423, 0.1249, 0.124431]

fig, ax = plt.subplots()
ax.plot(number, data, color='black')
plt.xlabel('训练次数', fontproperties=myfont)
plt.ylabel('损失函数值', fontproperties=myfont)
plt.title("日销量数据集", fontproperties=myfont)
# plt.title("客运量数据集",fontproperties=myfont)
# plt.title("出生率数据集",fontproperties=myfont)
# plt.title("人均粮食占有量数据集",fontproperties=myfont)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.legend()
fig = matplotlib.pyplot.gcf()
fig.set_size_inches(6, 4)
fig.savefig('test2png.png', dpi=350)
