# http://matplotlib.org/examples/api/date_demo.html
import matplotlib.dates as mdates
import pandas as pd
from pylab import *

myfont = matplotlib.font_manager.FontProperties(fname="E:\\fonts\msyhbd.ttf")
mpl.rcParams['axes.unicode_minus'] = False
# file = 'D:\PycharmProjects\paperData\日销量全部数据.csv'
# file = 'D:\PycharmProjects\paperData\铁路客运量全部数据.csv'
# file = 'D:\PycharmProjects\paperData\人口出生率全部数据.csv'
file = 'D:\PycharmProjects\paperData\粮食占有量全部数据.csv'

df = pd.read_csv(file)
# data = np.array(df['日销量'])
# data = np.array(df['铁路客运量当期值(万人)'])
# data = np.array(df['人口出生率(‰)'])
data = np.array(df['粮食人均占有量(公斤)'])
date = np.array(df['日期'])
new_date = []
for i in range(len(date)):
    # new_date_empty = datetime.datetime.strptime(date[i], '%Y/%m/%d')
    # new_date_empty = datetime.datetime.strptime(date[i], '%Y/%m')
    new_date_empty = datetime.datetime.strptime(date[i], '%Y/')
    new_date.append(new_date_empty)

months = mdates.MonthLocator()
years = mdates.YearLocator()
auto = mdates.AutoDateLocator()
dayFmt = mdates.DateFormatter('%Y-%m-%d')
monthFmt = mdates.DateFormatter('%Y-%m')
yearFmt = mdates.DateFormatter('%Y')

fig, ax = plt.subplots()
ax.plot(new_date, data, color='black')

ax.xaxis.set_major_locator(auto)
ax.xaxis.set_major_formatter(yearFmt)

fig.autofmt_xdate()
plt.xlabel('日期', fontproperties=myfont)

# plt.ylabel('日销量', fontproperties=myfont)
# plt.title("企业日销量数据集",fontproperties=myfont)

# plt.ylabel('铁路客运量当期值(万人)', fontproperties=myfont)
# plt.title("铁路客运量当前期数据集",fontproperties=myfont)

# plt.ylabel('人口出生率(‰)', fontproperties=myfont)
# plt.title("人口出生率数据集",fontproperties=myfont)

plt.ylabel('粮食人均占有量(公斤)', fontproperties=myfont)
plt.title("粮食人均占有量数据集", fontproperties=myfont)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
fig = matplotlib.pyplot.gcf()
fig.set_size_inches(9, 5)
fig.savefig('test2png.png', dpi=350)
# plt.show()
