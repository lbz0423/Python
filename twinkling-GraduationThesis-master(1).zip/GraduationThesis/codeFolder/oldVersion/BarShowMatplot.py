import matplotlib.pyplot as plt
from pylab import *

myfont = matplotlib.font_manager.FontProperties(fname="E:\\fonts\msyhbd.ttf")
mpl.rcParams['axes.unicode_minus'] = False

n_groups = 4

# ori_data_1 = (5191.38, 13001.73, 0.16, 93.77)
# ori_data_2 = (3758.18, 7229.22, 0.16, 64.40)
# ori_data_3 = (13003.84, 4575.13, 0.17, 112.57)
# ori_data_4 = (7726.95, 3685.18, 0.16, 70.10)

# ori_data_1 = (3802.79, 10330.32, 0.13, 79.57)
# ori_data_2 = (2667.55, 5578.76, 0.12, 58)
# ori_data_3 = (9951.61, 3829.43, 0.14, 82.90)
# ori_data_4 = (6352.32, 2990.78, 0.11, 54.63)

ori_data_1 = (323.96, 45.47, 1.04, 18.11)
ori_data_2 = (237.73, 24.47, 0.98, 13.20)
ori_data_3 = (618.08, 17.29, 1.11, 18.82)
ori_data_4 = (417.08, 13.52, 0.94, 12.37)

# data_1 = (ori_data_1[0], ori_data_1[1], ori_data_1[2]*10000, ori_data_1[3]*100)
# data_2 = (ori_data_2[0], ori_data_2[1], ori_data_2[2]*10000, ori_data_2[3]*100)
# data_3 = (ori_data_3[0], ori_data_3[1], ori_data_3[2]*10000, ori_data_3[3]*100)
# data_4 = (ori_data_4[0], ori_data_4[1], ori_data_4[2]*10000, ori_data_4[3]*100)

data_1 = (ori_data_1[0], ori_data_1[1] * 10, ori_data_1[2] * 100, ori_data_1[3] * 10)
data_2 = (ori_data_2[0], ori_data_2[1] * 10, ori_data_2[2] * 100, ori_data_2[3] * 10)
data_3 = (ori_data_3[0], ori_data_3[1] * 10, ori_data_3[2] * 100, ori_data_3[3] * 10)
data_4 = (ori_data_4[0], ori_data_4[1] * 10, ori_data_4[2] * 100, ori_data_4[3] * 10)

fig, ax = plt.subplots()
index = np.arange(4)
bar_width = 0.2

rects1 = plt.bar(index, data_1, bar_width, alpha=0.4, color='black')
rects2 = plt.bar(index + bar_width, data_2, bar_width, alpha=0.9, color='black')
rects3 = plt.bar(index + bar_width + bar_width, data_3, bar_width, alpha=0.4, color='black')
rects4 = plt.bar(index + 3 * bar_width, data_4, bar_width, alpha=0.9, color='black')

plt.xlabel('数据集', fontproperties=myfont)
plt.ylabel('MAPE值', fontproperties=myfont)
plt.title('MAPE值数据集对比', fontproperties=myfont)
plt.xticks(index + 1.5 * bar_width, ('日销量', '客运量', '出生率', '粮食占有量'), fontproperties=myfont)
plt.yticks()
plt.legend(['GRU模型', 'GRU-SES模型', ], prop=myfont)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.legend()
fig = matplotlib.pyplot.gcf()
fig.set_size_inches(9, 5)
fig.savefig('test2png.png', dpi=300)
# plt.show()
