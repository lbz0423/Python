import numpy as np

ori_data = [2580, 677, 4059, 1131, 3199, 1452, 3765, 1745, 1142, 1746]
gru_data = [938.83, 9364.61, 11751.98, 21122.08, 10771.73, 8837.27, 22156.25, 28249.16, 2121.04, 2416.85]
secgru_data = [3106.71, 7314.74, 8503.57, 13183.76, 8003.73, 7031.64, 13686.27, 16727.87, 3658.95, 3802.0]

b = 0
for i in range(0, len(ori_data)):
    a = np.square(gru_data[i] - ori_data[i])
    b = b + a
c = np.sqrt(b / (len(ori_data)))
print(c)

f = 0
for j in range(0, len(ori_data)):
    e = np.square(secgru_data[j] - ori_data[j])
    f = f + e
g = np.sqrt(f / (len(ori_data)))
print(g)
